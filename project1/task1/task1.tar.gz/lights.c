#include "lights.h"


void setupRightLED(void) {
	DDRD |= (1 << 5);
}

void rightLEDon(void) {
	PORTD &= ~(1 << 5);
} 

void rightLEDoff(void) {
	PORTD |= (1 << 5);
}

void setupLeftLED(void) {
	DDRD |= (1 << 6);
}

void leftLEDon(void) {
	PORTD &= ~(1 << 6);
} 

void leftLEDoff(void) {
	PORTD |= (1 << 6);
}

void changePowerLightRed(void) {
	byteTx(CmdLeds);
  byteTx(0x00);
  byteTx(255);
  byteTx(255);
}